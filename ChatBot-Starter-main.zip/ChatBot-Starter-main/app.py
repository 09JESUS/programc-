from flask import Flask, render_template, request, jsonify
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

app = Flask(__name__)

# Load DialoGPT model and tokenizer
tokenizer = AutoTokenizer.from_pretrained("microsoft/DialoGPT-medium")
model = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-medium")

# Global variable to store chat history
chat_history_ids = {"client": None, "agent": None}

@app.route("/")
def index():
    return render_template('index.html')

@app.route("/client")
def client():
    return render_template('client.html')

@app.route("/agent")
def agent():
    return render_template('agent.html')

@app.route("/send_message", methods=["POST"])
def send_message():
    msg = request.form["msg"]
    session_id = request.form["session_id"]

    # Determine sender and receiver
    sender = session_id
    receiver = "agent" if session_id == "client" else "client"

    # Generate response from the chatbot model
    bot_response = generate_response(msg, model, tokenizer, chat_history_ids[sender])

    # Update chat history for both sender and receiver
    chat_history_ids[sender] = bot_response["chat_history"]
    chat_history_ids[receiver] = bot_response["chat_history"]

    # Format the response to send back to the client
    response_data = {
        "bot": bot_response["response"]
    }

    return jsonify(response_data)

def generate_response(text, model, tokenizer, chat_history_ids):
    new_user_input_ids = tokenizer.encode(text + tokenizer.eos_token, return_tensors='pt')
    bot_input_ids = torch.cat([chat_history_ids, new_user_input_ids], dim=-1) if chat_history_ids is not None else new_user_input_ids
    attention_mask = torch.ones(bot_input_ids.shape, dtype=torch.long)
    chat_history_ids = model.generate(bot_input_ids, max_length=1000, pad_token_id=tokenizer.eos_token_id, attention_mask=attention_mask)
    response = tokenizer.decode(chat_history_ids[:, bot_input_ids.shape[-1]:][0], skip_special_tokens=True)
    return {"response": response, "chat_history": chat_history_ids}

if __name__ == '__main__':
    app.run(debug=True)
